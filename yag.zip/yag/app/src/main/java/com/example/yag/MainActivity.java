// MainActivity.java
package com.example.yag;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Question[] questions = new Question[]{
            new Question("What is the capital of France?", new String[]{"Paris", "London", "Berlin", "Madrid"}, "Paris"),
            new Question("What is 2 + 2?", new String[]{"3", "4", "5", "6"}, "4"),
            // Add more questions here
    };

    private int currentQuestionIndex = 0;
    private int score = 0;

    private TextView questionTextView;
    private RadioGroup answersRadioGroup;
    private Button submitButton;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        questionTextView = findViewById(R.id.questionTextView);
        answersRadioGroup = findViewById(R.id.answersRadioGroup);
        submitButton = findViewById(R.id.submitButton);
        resultTextView = findViewById(R.id.resultTextView);

        loadQuestion();

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
                if (currentQuestionIndex < questions.length - 1) {
                    currentQuestionIndex++;
                    loadQuestion();
                } else {
                    showResult();
                }
            }
        });
    }

    private void loadQuestion() {
        Question currentQuestion = questions[currentQuestionIndex];
        questionTextView.setText(currentQuestion.getQuestion());

        for (int i = 0; i < answersRadioGroup.getChildCount(); i++) {
            RadioButton radioButton = (RadioButton) answersRadioGroup.getChildAt(i);
            radioButton.setText(currentQuestion.getChoices()[i]);
        }

        answersRadioGroup.clearCheck();
    }

    private void checkAnswer() {
        int selectedId = answersRadioGroup.getCheckedRadioButtonId();
        RadioButton selectedRadioButton = findViewById(selectedId);
        String selectedAnswer = selectedRadioButton.getText().toString();

        if (selectedAnswer.equals(questions[currentQuestionIndex].getAnswer())) {
            score++;
        }
    }

    private void showResult() {
        resultTextView.setText("Your score: " + score + "/" + questions.length);
        resultTextView.setVisibility(View.VISIBLE);
        submitButton.setEnabled(false);
    }
}
